﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ПР_13.Classes
{
    class ConnectHelper
    {
        public static List<Student> students = new List<Student>();
    }
}
