﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ПР_13.Classes
{
    class Student
    {
        string FIO;
        string group;
        int Math;
        int Rus;
        int Xim;
        int Bio;
        int Geografy;
        public string fio
        {
            get { return FIO; }
            set { FIO = value; }
        }
        public string Group
        {
            get { return group; }
            set { group = value; }
        }
        public int math
        {
            get { return Math; }
            set { Math = value; }
        }
        public int rus
        {
            get { return Rus; }
            set { Rus = value; }
        }
        public int xim
        {
            get { return Xim; }
            set { Xim = value; }
        }
        public int bio
        {
            get { return Bio; }
            set { Bio = value; }
        }
        public int geografy
        {
            get { return Geografy; }
            set { Geografy = value; }
        }
        public Student()
        {
            FIO = "";
            group = "";
            Math = 0;
            Rus = 0;
            Xim = 0;
            Bio = 0;
            Geografy = 0;
        }
        public Student(string student, string gr, int M, int R, int X, int B, int Geo)
        {
            FIO = student;
            group = gr;
            Math = M;
            Rus = R;
            Xim = X;
            Bio = B;
            Geografy = Geo;
        }
    }
}
