﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ПР_13.Classes;

namespace ПР_13
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.students.Add(new Student("Баженов А. М.", "ИСП.20А", 5, 5, 5, 5, 5));
            ConnectHelper.students.Add(new Student("Андреев Д. М.", "ИСП.19А", 5, 4, 3, 5, 5));
            ConnectHelper.students.Add(new Student("Устинова А. Д.", "ИСП.20А", 4, 5, 4, 5, 5));
            ConnectHelper.students.Add(new Student("Токарева В. Н.", "ТСИ-20", 4, 4, 4, 4, 5));
            ConnectHelper.students.Add(new Student("Яковлева А. К.", "ИСП.19А", 4, 5, 3, 3, 5));
            ConnectHelper.students.Add(new Student("Зайцев Д. И.", "ТСИ-20", 3, 3, 3, 5, 5));
            ConnectHelper.students.Add(new Student("Маслова Д. Д.", "ТСИ-20", 5, 5, 5, 5, 5));
            ConnectHelper.students.Add(new Student("Черкасов Т. А.", "ТСИ-20", 5, 4, 5, 4, 5));
            ConnectHelper.students.Add(new Student("Бондарева К. А.", "ИСП.20А", 5, 4, 5, 4, 5));
            ConnectHelper.students.Add(new Student("Крюкова О. А.", "ИСП.20А", 4, 4, 4, 4, 4));
            DtgListStudent.ItemsSource = ConnectHelper.students;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListStudent.ItemsSource = ConnectHelper.students.ToList();
            DtgListStudent.SelectedIndex = -1;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgListStudent.ItemsSource = ConnectHelper.students.Where(x => x.fio.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAdd windowAdd = new WindowAdd();
            windowAdd.ShowDialog();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListStudent.ItemsSource = null;
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListStudent.ItemsSource = ConnectHelper.students.OrderBy(x => x.fio).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListStudent.ItemsSource = ConnectHelper.students.OrderByDescending(x => x.fio).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                
                DtgListStudent.ItemsSource = ConnectHelper.students.Where(x => x.Group == "ИСП.20А").ToList();
                
            }
            else
                if (CmbFiltr.SelectedIndex == 1)
            {
                DtgListStudent.ItemsSource = ConnectHelper.students.Where(x => x.Group == "ИСП.19А").ToList();

            }
            else
            {
                DtgListStudent.ItemsSource = ConnectHelper.students.Where(x => x.Group == "ТСИ-20").ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
